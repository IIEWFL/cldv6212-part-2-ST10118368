using System;
using System.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace Aweh_Productions_2._1B
{
    public class Function1
    {
        [FunctionName("ST10118368")]
        public void Run([QueueTrigger("aweh-productions-queue", Connection = "QueueCon")]string myQueueItem, ILogger log)
        {
            string conString = "Server=tcp:poe-2023.database.windows.net,1433;Initial Catalog=POE_2023;Persist Security Info=False;User ID=david;Password=Dash2023;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            try
            {
                //Delcare
                string id = "";
                string vaccineCentre = "";
                string vaccinationDate = "";
                string vaccineSerialNumber = "";

                //Splitting the message into parts to store.
                String[] attributes = myQueueItem.Split(':');

                //Check whether first attribute is the ID or Vaccine Barcode
                string checkAttribute = attributes[0];

                if (checkAttribute.Count() == 13)
                {
                    id = attributes[0];
                    vaccineCentre = attributes[1];
                    vaccinationDate = attributes[2];
                    vaccineSerialNumber = attributes[3];

                }
                else
                {
                    vaccineSerialNumber = attributes[0];
                    vaccinationDate = attributes[1];
                    vaccineCentre = attributes[2];
                    id = attributes[3];
                }

                //Process Message
                log.LogInformation($"Processing queue: {myQueueItem}");

                using (SqlConnection connection = new SqlConnection(conString))
                {
                    connection.Open();

                    string query = "INSERT INTO Awe_Production_Message (ID, [Vaccination Centre], [Vaccination Date], [Vaccine Serial Number]) VALUES (@ID, @Vaccination_Centre, @Vaccination_Date, @Vaccine_Serial_Number)";
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = query;
                        command.Parameters.AddWithValue("@ID", id);
                        command.Parameters.AddWithValue("@Vaccination_Centre", vaccineCentre);
                        command.Parameters.AddWithValue("@Vaccination_Date", vaccinationDate);
                        command.Parameters.AddWithValue("@Vaccine_Serial_Number", vaccineSerialNumber);
                        command.ExecuteNonQuery();

                    }
                }

                //Logging mesaage details
                log.LogInformation($"Queue message successfully stored ID = {id} | Vaccination Centre = {vaccineCentre} | Vaccination Date = {vaccinationDate} | Vaccine Serial Number = {vaccineSerialNumber}");

            }
            catch(Exception ex) 
            {
                log.LogError("Processing Error: " +ex.Message);
            }
        }
    }
}
